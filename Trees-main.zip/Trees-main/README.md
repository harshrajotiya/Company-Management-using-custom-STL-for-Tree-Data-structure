# Trees Standard Library

Here, we have explained all the functions of our Trees Standard Library

1. **Build tree** - This function builds the binary tree with nodes as -1 and other nodes as integer value.
Function name - node * buildtree() 
Its time complexity - O(n)
Its space complexity - O(1)  

2. **Print Preorder** - This function prints our binary tree in pre - order.
Preorder - 1.Node 
	        2.Left
	        3.Right
Function name - void printInPreOrder(node * root)
Its time complexity- O(n)
Its space complexity- O(1)

3. **Print Postorder** -  This function prints our binary tree in Post - Order 
Preorder - 1.Left
	        2.Right
	        3.Node 
Function name - void printInPost(node * root)
Return type- void
Its time complexity - O(n)
Its space complexity - O(1)


4. **Print Inorder** -  This function prints our binary tree in In - Order 
Preorder - 1.Left
	        2.Node
	        3.Right
Function name - void printinorder(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

5. **Height** - This function returns the heights of the tree.
Function name -  int height(node * root)
Its time complexity - O(n)
Its space complexity - O(1)
6. **Print Level Order** -  This function prints our binary tree in level order. 
First level in the first line ….
Second level in the second line … and so on...
Function name - void levelordercall(node * root)
Its time complexity - O(n^2)
Its space complexity - O(1)


7. **Print kth Level Order** -  This function prints the kth level of our binary tree . 
K - level you want to print
Function name - void levelOrderHeight(node * root,int k)
Its time complexity - O(n)
Its space complexity - O(1)



8. **Print Level Order using Queue** -  This function prints our binary tree in  level order. 
All the levels in one line only
Function name -void levelorderusingQueue(node * root)
Its time complexity - O(n)
Its space complexity - O(n)

9. **Print Level Order using Queue** -  This function prints our binary tree in  level order. 
All the levels in different lines ie. using endl.
Function name -void levelorderPerfect(node * root)
Its time complexity - O(n)
Its space complexity - O(n)


10. **Count number of Nodes** - This function returns the total number of nodes in our binary tree.
Function name -int countNode(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

11. **Sum all the of Nodes** - This function returns the sum of all the nodes in our binary tree.
Function name -int sumOfAllNodes(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

12. **Diameter of tree** - This function returns the diameter of the tree.
Function name -int diameterinOn2(node * root)
Its time complexity - O(n^2)
Its space complexity - O(1)

13. **Diameter of tree** - This function returns the diameter of the tree.
Function name - Pair diameterOfTreeOpt(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

14. **Replace Nodes by its child sum** - This function replaces all the nodes by its child sum and in the end it also returns the sum of all the nodes ie. the value of root node.
Function name -int nodeBychildNode(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

15. **Check for height balance** - This function returns true if our tree is height balance if its not height balanced it returns false.
Function name -bool isBalance(node * root)
Its time complexity - O(n^2)
Its space complexity - O(1)


16. **Check for height balance** - This function returns true if our tree is height balance if its not height balanced it returns false.
Function name -pairForbalance isBalanceOpt(node * root)
Its time complexity - O(n)
Its space complexity - O(1)


17. **Build a height balanced tree** - This function builds a height balanced tree from an array and returns the root node .
Function name -node * buildHeightBalancedaTree(int *a,int s,int e)
Its time complexity - O(n)
Its space complexity - O(1)

18. **Left View** - This function prints the left view of a given tree using queue data structure.
Function name - void leftView(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

19. **Right View** - This function prints the right view of a given tree using queue data structure.
Function name - void rightView(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

20. **Top View** - This function prints the top view of a given tree .
To print the top view of a tree we need to call both these functions...
Function name -void treeTopViewleft(node * root) ,
void treeTopViewRight(node * root,node * orignal)
Its time complexity - O(n)
Its space complexity - O(1)

21. **Create a binary tree from preorder and inorder** - This function builds a binary tree using the preorder and inorder given by the user.
Function name - node * createTreeUsingOrders(int *in,int * pre,int s,int e)
Here -
In = inorder traversal in form of an array
pre= preorder traversal in form of an array
s= 0 
e= size of in/pre -1 
Its time complexity - O(n)
Its space complexity - O(1)

22. **Nodes at k Distance in sub** - This function prints all the node at a distance of k nodes in the subtree from a given node.
Function name -void nodeAtKinSub(node * root,int k)
Its time complexity - O(n)
Its space complexity - O(1)

23. **Nodes at k Distance** - This function prints all the node at a distance of k nodes in the whole tree from a given node also it returns the count of no of nodes at k distance.
Function name -int nodeAtKDis(node * root,node * target,int k)
Its time complexity - O(n)
Its space complexity - O(1)

24. **Check identical trees** - This function returns true if our two trees are identical if they are not identical it returns false.
Function name -bool areTreeidentical(node *a,node *b)
Its time complexity - O(n)
Its space complexity - O(1)

25. **Check Structurally identical trees** - This function returns true if our two trees are structurally identical if they are not structurally identical it returns false.
Function name -bool areTreesStructurallyIdentical(node*A,node* B) 
Its time complexity - O(n)
Its space complexity - O(1)


26. **Zig Zag View** - This function prints the zig zag view of a given tree with first level printing from left to right then second level from right to left and so on.....
Function name - void printZigZag(node * root)
Its time complexity - O(n)
Its space complexity - O(1)

27. **Minimum of BST** - This function returns the minimum element of a binary search tree.
Function name - node* FindMin(node *Node) 
Its time complexity - O(h)
Its space complexity - O(1)


27. **Maximum of BST** - This function returns the maximum element of a binary search tree.
Function name - node* FindMax(node *Node)  
Its time complexity - O(h)
Its space complexity - O(1)


28. **Insertion in BST** - This function inserts a particular value in binary search tree.
Function name - node *Insert(node *Node,int data) 
Its time complexity - O(n)
Its space complexity - O(1).

29. **Delete in BST** - This function deletes a particular value in binary search tree.
Function name - node * Delet(node *Node, int data)
Its time complexity - O(n)
Its space complexity - O(1).


30. **Search in BST** - This function searchs a particular value in binary search tree.
Function name - node * Find(node *Node, int data) 
Its time complexity - O(n)
Its space complexity - O(1).


31. **Build a Minimum segment tree** - This function builds a minimum segment tree from an array 
Function name - void buildTree1(int *tree,int *arr,int index,int s,int e)
Its time complexity - O(n)
Its space complexity - O(1).

32. **Build a Maximum segment tree** - This function builds a maximum segment tree from an array 
Function name - void buildTree2(int *tree,int *arr,int index,int s,int e)
Its time complexity - O(n)
Its space complexity - O(1).


33. **Minimum element in min segment tree** - This function returns a minimum element from the minimum segment tree in the given range.
Function name - int query1(int *tree,int index,int s,int e,int qs,int qe)
Its time complexity - O(n)
Its space complexity - O(1).


33. **Maximum element in max segment tree** - This function returns a max element from the max segment tree in the given range.
Function name - int query2(int *tree,int index,int s,int e,int qs,int qe)
Its time complexity - O(n)
Its space complexity - O(1).


34. **Update any node in segment tree** - This function updates any node in segment tree .
Function name - void updateNode(int *tree,int index,int s,int e,int i,int val)
Its time complexity - O(n)
Its space complexity - O(1).


35. **Update the range in segment tree** - This function updates the whole range in segment tree given by the user.
Function name - void updateRange(int *tree,int index,int s,int e,int rs,int re,int val)
Its time complexity - O(n)
Its space complexity - O(1).

36. **Visualize tree** - This function prints the given tree in more presentable order .
Function name - void Beautify( node * root)
Its time complexity - O(n)
Its space complexity - O(1).

37. **Bold_on** - This function makes the compiler to print in bold letters.
Function name - bold_on
Its time complexity - O(1)
Its space complexity - O(1).

38. **Bold_off** - This function makes the compiler to switch off the  bold on letters.
Function name - bold_off
Its time complexity - O(1)
Its space complexity - O(1).

38. **Lowest Common Ancestor** - This function returns the Lowest Common Ancestor .
Function name - chart * lca(chart * root,chart * n1,chart *n2)
Its time complexity - O(n)
Its space complexity - O(1).

39. **Print Path between two nodes** - This function prints the path between two nodes.
Function name - void printPathBetweenNodes(chart * root, string  n1, string n2) 
Its time complexity - O(n)
Its space complexity - O(1).

